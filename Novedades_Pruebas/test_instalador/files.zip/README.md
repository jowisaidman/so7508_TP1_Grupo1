# Primer Trabajo Practico Sistemas Operativos

Para iniciar: 
    bash start.sh

Para frenar:
    bash stop.sh